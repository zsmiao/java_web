create
    definer = root@`%` procedure test()
begin
    #执行体部分
    select * from titles;
        end;

